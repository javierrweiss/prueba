package trabajopracticopoo2.vinoapp.enumerados;
public enum Medalla {oro, plata, bronce}
