package trabajopracticopoo2.vinoapp.enumerados;
public enum Color {
tinto,blanco,rosado    
}
