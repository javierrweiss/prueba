package trabajopracticopoo2.vinoapp.enumerados;
public enum Categoria {joven,reserva,gran_reserva,espumante_extrabrut,
espumante_brut,espumante_sec,espumante_demisec,licoroso,late_harvest}
