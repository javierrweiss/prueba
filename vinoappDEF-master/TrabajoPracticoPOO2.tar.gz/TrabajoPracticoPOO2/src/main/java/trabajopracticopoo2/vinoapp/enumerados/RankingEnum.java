package trabajopracticopoo2.vinoapp.enumerados;
public enum RankingEnum {
r1,r2,r3,r4,r5   
}
